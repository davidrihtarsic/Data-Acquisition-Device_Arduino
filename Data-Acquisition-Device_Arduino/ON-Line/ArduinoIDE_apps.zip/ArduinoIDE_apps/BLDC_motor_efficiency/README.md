# Measuring BLDC motor's efficiency

Connect the BLDC motor as is shown on picture
![Block scheme of setup\label{postavitev}](izkoristek-BLDC-motorja.bmp)

Upload the program ...