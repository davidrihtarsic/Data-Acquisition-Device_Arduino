# Color sensor TCS3200

[datasheet](https://www.mouser.com/catalog/specsheets/TCS3200-E11.pdf)
